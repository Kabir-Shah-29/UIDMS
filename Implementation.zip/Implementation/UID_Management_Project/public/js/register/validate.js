
const validation = () => {
    const user = document.querySelector('#username').value;
    const email = document.querySelector('#email').value;
    const pass = document.querySelector('#pass').value;
    const confPass = document.querySelector('#confPass').value;
    const mob = document.querySelector('#mob').value;
    const birthCertificate = document.querySelector('#birthCertificate').value;
    const address = document.querySelector('#address').value;

    // regex expression

    const userReg = /^[a-zA-Z. ]{3,30}$/;
    const passwordReg = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;
    const emailReg = /^[A-Za-z_]{2,}[0-9]*@[A-Za-z]{3,}[.]{1}[A-Za-z.]{2,6}$/;
    const mobReg = /^[6789][0-9]{9}$/;
    const birthCertificateReg = /^[0-9]{6}$/;
    const addressReg = /^[a-zA-z, ]+[0-9, ]*[a-zA-z0-9, ]*$/;


    if (!userReg.test(user)) {
        swal({
            title: "Sorry There Are Errors, Fill Properly",
            text: "Enter Your Proper Name , Another Things Are Not Allowed ! 😡",
            icon: "error",
            button: "Correct it 😏",
        });
        return false;
    }
    else if (!passwordReg.test(pass)) {

        swal({
            title: "Sorry There Are Errors, Fill Properly",
            text: "Password Should Have At Least 6 Character With At Least 1 Special Character and At Least 1 Digit 😣",
            icon: "error",
            button: "Correct it 😏",
        });
        return false
    }
    else if (pass !== confPass) {
        swal({
            title: "Sorry There Are Errors, Fill Properly",
            text: "Password Is Not Matching 🙄😫 Check Again",
            icon: "error",
            button: "Correct it 😏",
        });
        return false
    }
    else if (!mobReg.test(mob)) {
        swal({
            title: "Sorry There Are Errors, Fill Properly",
            text: "Invalid Mobile Number, Enter The India Specific Mobile Number 😣",
            icon: "error",
            button: "Correct it 😏",
        });
        return false;
    }
    else if (!birthCertificateReg.test(birthCertificate)) {

        swal({
            title: "Sorry There Are Errors, Fill Properly",
            text: "Invalid Birth Certificate  Number 😫",
            icon: "error",
            button: "Correct it 😏",
        });
        return false;
    }
    else if (!emailReg.test(email)) {
        swal({
            title: "Sorry There Are Errors, Fill Properly",
            text: "Invalid Email Address 😫",
            icon: "error",
            button: "Correct it 😏",
        });
        return false;
    }
    else if (!addressReg.test(address)) {
        swal({
            title: "Sorry There Are Errors, Fill Properly",
            text: "Write Proper Address 😧 (start with alphabets first don't use symbol like (-,@,$,#,!) just use space and comma) 🧑",
            icon: "error",
            button: "Correct it 😏",
        });
        return false;
    }
    else {
        swal({
            title: "🎊 Welcome 🎊",
            text: "Successfully Registered😊",
            icon: "success",
            button: "Welcome 🎊",
        });
        return true;
    }

}