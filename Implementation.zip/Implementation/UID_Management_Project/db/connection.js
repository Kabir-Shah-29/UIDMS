const mongoose = require('mongoose');

mongoose.connect('mongodb+srv://princetirmal:prince81@cluster0.l4ky3.mongodb.net/userInfo?retryWrites=true&w=majority', () => {
    console.log('connected')
}).catch(err => {
    console.log(err);
})