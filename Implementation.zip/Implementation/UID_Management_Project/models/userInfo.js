const { default: mongoose } = require("mongoose");

const userInfoSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true,
        trim: true
    },
    email: {
        type: String,
        required: true,
        unique: true,
    },
    password: {
        type: String,
        required: true,
        unique: true,
    },
    mobileNumber: {
        type: Number,
        required: true,
    },
    birthCertificate: {
        type: String,
        required: true,
    },
    address: {
        type: String,
        required: true,
        trim: true,
    }
})

// model

const UserInfo = new mongoose.model('UserInfo', userInfoSchema);

module.exports = UserInfo;
