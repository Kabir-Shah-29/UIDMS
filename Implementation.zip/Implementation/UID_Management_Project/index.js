// database
require('./db/connection');
const express = require('express');
const app = express();

// model
const UserInfo = require('./models/userInfo');

// middleware
app.use(express.static('./public'))
app.set('view engine', 'hbs');
app.use(express.json())
app.use(express.urlencoded({ extended: false }));


// Routes
app.get('/register', (req, res) => {
    if (res.statusCode == 404) {
        res.status(404).render('register', {
            errorStatus: alertKey,
        })
    } else {
        res.render('register')
    }
})

app.post('/create', async (req, res) => {
    try {
        console.log(req.body);
        const createUser = new UserInfo({
            username: req.body.username,
            email: req.body.email,
            password: req.body.password,
            mobileNumber: req.body.mobileNumber,
            birthCertificate: req.body.birthCertificate,
            address: req.body.address
        })
        const result = await createUser.save();
        res.status(201).redirect('/login');
    } catch (err) {
        const alert = err.keyPattern
        console.log(err);
        const alertKey = Object.keys(alert)[0];
        console.log(alertKey)
        res.status(404).redirect('register');
    }
})



app.get('/login', (req, res) => {
    res.render('login')
})

app.get('/join', async (req, res) => {
    try {
        const result = await UserInfo.findOne({ $and: [{ email: req.body.email }, { password: req.body.password }] });
        if (result)
            res.json("successfully Login")
        else {
            res.json('error');
        }
    } catch (err) {

    }
})

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`${PORT} is running`);
})